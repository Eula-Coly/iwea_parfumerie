---
name: Haute Parfumerie & Atelier Sensoriel
colors:
  surface: '#fbf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#fbf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f0'
  surface-container: '#efeeeb'
  surface-container-high: '#eae8e5'
  surface-container-highest: '#e4e2df'
  on-surface: '#1b1c1a'
  on-surface-variant: '#43474a'
  inverse-surface: '#30312f'
  inverse-on-surface: '#f2f0ed'
  outline: '#73787a'
  outline-variant: '#c3c7ca'
  surface-tint: '#526167'
  primary: '#1d2b31'
  on-primary: '#ffffff'
  primary-container: '#334147'
  on-primary-container: '#9eadb4'
  inverse-primary: '#bac9d0'
  secondary: '#765938'
  on-secondary: '#ffffff'
  secondary-container: '#fed6ad'
  on-secondary-container: '#795b3b'
  tertiary: '#471a27'
  on-tertiary: '#ffffff'
  tertiary-container: '#612f3c'
  on-tertiary-container: '#db97a7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e5ec'
  primary-fixed-dim: '#bac9d0'
  on-primary-fixed: '#0f1d23'
  on-primary-fixed-variant: '#3b494f'
  secondary-fixed: '#ffddbb'
  secondary-fixed-dim: '#e6c098'
  on-secondary-fixed: '#2b1700'
  on-secondary-fixed-variant: '#5c4123'
  tertiary-fixed: '#ffd9e0'
  tertiary-fixed-dim: '#fbb3c3'
  on-tertiary-fixed: '#360c1a'
  on-tertiary-fixed-variant: '#6b3744'
  background: '#fbf9f6'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2df'
typography:
  display-lg:
    fontFamily: EB Garamond
    fontSize: 4rem
    fontWeight: '600'
    lineHeight: 4.5rem
    letterSpacing: -0.01em
  display-sm:
    fontFamily: EB Garamond
    fontSize: 2.75rem
    fontWeight: '600'
    lineHeight: 3.25rem
    letterSpacing: -0.005em
  headline-lg:
    fontFamily: EB Garamond
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: 2.75rem
    letterSpacing: 0em
  headline-lg-mobile:
    fontFamily: EB Garamond
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.25rem
    letterSpacing: 0em
  headline-sm:
    fontFamily: EB Garamond
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: 2rem
    letterSpacing: 0.01em
  title-md:
    fontFamily: Montserrat
    fontSize: 1.125rem
    fontWeight: '500'
    lineHeight: 1.75rem
    letterSpacing: 0.02em
  body-lg:
    fontFamily: Montserrat
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.65rem
    letterSpacing: 0.01em
  body-md:
    fontFamily: Montserrat
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: 0.015em
  label-lg:
    fontFamily: Montserrat
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1.25rem
    letterSpacing: 0.18em
  label-sm:
    fontFamily: Montserrat
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.22em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-desktop: 2.5rem
  margin: 1.25rem
  margin-desktop: 4rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
---

## Brand & Style

This design system expresses artisanal French perfumery through a contemporary luxury lens. It balances classical refinement with architectural precision, evoking sensations of olfactory craftsmanship, delicate warm skin, and precious metallic accents. 

The aesthetic is an editorial minimalist expression: generous breathing room, crisp typographic contrast, warm tactile light backgrounds, hairline borders, and subtle metallic illumination. The interface feels serene, poised, and tactile rather than sterile or aggressively commercial. Every touchpoint conveys bespoke care, intimacy, and sensory calm while maintaining strict WCAG AA legibility standards.

## Colors

The palette directly honors the official brand board:

- **Gris Anthracite (`#334147`)**: The dominant structural color. Used for primary typography, authoritative surfaces, dark-mode containers, and crisp interactive states. It delivers a contrast ratio exceeding 9:1 against the light canvas, ensuring flawless WCAG AA/AAA compliance.
- **Bronze Doré (`#AA8864`)**: The signature warm metallic tone. Reserved for focal interactions, active pill indicators, elevated callouts, refined borders, and bespoke iconography.
- **Bronze Clair / Détail Feuille (`#CB8998`)**: A muted dusty-rose copper nuance used for delicate accents, tag indicators, gentle badges, and subtle hover glows.
- **Ligne Gris Moyen (`#879955` / Blue-Grey Variant `#788A94`)**: Utilitarian structure tone for secondary outlines, divider rules, and secondary state descriptors.
- **Fond Écru Chaud / Ivoire (`#FAF8F5` / `#F5F1EB`)**: The primary canvas background, creating a warm, paper-like sensory texture rather than cold hospital white. Pure white (`#FFFFFF`) is reserved for card interiors to establish gentle layer elevation.

## Typography

The typographic architecture establishes a dialogue between artisanal French tradition and contemporary editorial restraint:

- **Display & Headings (EB Garamond)**: Serves as the web counterpart to Cormorant Garamond, providing classical serif rhythm, noble proportions, and warmth. Used in SemiBold (`600`) and Medium (`500`) weights for collection titles, fragrance notes, and hero narratives.
- **Body & Secondary Copy (Montserrat)**: Delivers clear, architectural geometric balance. Regular (`400`) and Medium (`500`) weights are used for descriptive text and product features.
- **Uppercase Eyebrows & Overlines**: Rendered in Montserrat with wide tracking (`letter-spacing: 0.18em` to `0.22em`), referencing the signature brandmark presentation (`L'ATELIER` and `PARFUM`).

## Layout & Spacing

The layout embraces high-end editorial proportions with wide margins and intentional pause points:

- **Grid Architecture**: 12-column responsive layout for desktop (1440px max-width container), reflowing to 6 columns on tablet, and 4 columns on mobile devices.
- **Rhythm & Breathing Room**: Content cards and sensory imagery utilize open margins (`space-xl` between thematic blocks) to mirror physical exhibition spaces. 
- **Component Padding**: Standard internal padding adheres to multiples of 4px and 8px, prioritizing vertical breathing room inside interactive elements to convey luxury.

## Elevation & Depth

Visual hierarchy rejects heavy, artificial drop shadows in favor of ambient warmth and delicate line work:

- **Surface Tiers**: Base canvas rests on warm écru (`#FAF8F5`). Cards sit on pure soft white (`#FFFFFF`) or tinted ivory (`#F5F1EB`), delineated by subtle 1px hairline borders (`rgba(170, 136, 100, 0.2)` or `rgba(51, 65, 71, 0.08)`).
- **Subtle Ambient Diffusion**: Floating dialogs, elevated menus, and shopping bags employ ultra-soft, warm-tinted shadows: `box-shadow: 0 12px 32px -4px rgba(51, 65, 71, 0.06), 0 4px 12px -2px rgba(170, 136, 100, 0.04)`.
- **Translucent Overlays**: Sticky headers and navigation bars utilize subtle frosted backdrops (`rgba(250, 248, 245, 0.88)` with `backdrop-filter: blur(12px)`) framed by a bottom hairline rule in bronze doré.

## Shapes

The design language favors architectural discipline and understated softness:

- **Geometry**: Base elements utilize soft, tailored corner radiuses (`roundedness: 1`, translating to `0.25rem` / `4px` on buttons, inputs, and badges; `0.5rem` / `8px` on product display cards).
- **Pill Exceptions**: Sensory scent tags, olfactive category chips, and floating badge indicators may use fully circular pill contours (`rounded-full`) to contrast against structured rectangular framing.

## Components

- **Buttons**:
  - *Primary*: Gris Anthracite (`#334147`) background with warm écru (`#FAF8F5`) text in uppercase Montserrat (`label-lg`), with subtle bronze border transitions on hover.
  - *Secondary / Luxury Accent*: Bronze Doré (`#AA8864`) fill with pure white typography, or transparent with a 1.5px Bronze Doré outline.
  - *Tertiary*: Clean text link with a 1px baseline underline and 0.18em tracking.
- **Chips & Olfactive Tags**:
  - Encapsulated pills in warm écru (`#F5F1EB`) with 1px border in `#AA8864` (30% opacity). Selected states fill with solid `#AA8864` and display white text.
- **Input Fields**:
  - Understated baseline or full-box containers with `#F5F1EB` background and a refined 1px border in `#788A94` (30% opacity). Focus states shift to a crisp `#AA8864` hairline border without loud outer glow halos.
- **Checkboxes & Radios**:
  - Custom square/circular controls framed in Gris Anthracite with Bronze Doré fill on activation.
- **Fragrance Showcase Cards**:
  - Soft white surfaces framed with hairline borders. Images are staged against natural écru podiums, followed by centered EB Garamond headings, olfactory pyramid summaries, and tracked price displays.